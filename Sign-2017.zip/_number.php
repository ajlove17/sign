
		 <h2>Numbers</h2>
          <div class="row">
            <div class="col-xs-5 ">
        
              <ul id="js-navDetail" class="detail-nav">
			  <? 
				for($x = 0; $x < 10; $x++) {
					echo  "<li><a href='#detail'>" .  $x . "</a></li>";
				}
				?>
			  </ul>
            </div><!--/.col-xs-6-->
            <div   id="detail" class="col-xs-7 ">
              <big id="js-detail" class="ASL">0</big>
            </div><!--/.col-xs-6-->
            

          </div><!--/row-->
       
      

 
	<script type="text/javascript" src="./assets/js/main.js"></script>

