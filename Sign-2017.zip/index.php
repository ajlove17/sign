
 <!DOCTYPE html>
<html>
<head>
<title>Sign</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<link rel="stylesheet" href="./assets/css/style.css"/>



</head>
<body>

		  <?php
if(!$_GET['PG']){

echo '<div class="container">';
} else {
echo '<div class="container "' .  $_GET['PG'] . '">';
}
?>





<div class="jumbotron">
  <div class="clearfix">
    <img src="./assets/img/Mr_P.png" alt="MR. F. R. Print says..." class="img-responsive visible-xs-block col-xs-6 pull-right ">
    <div class="col-sm-6 col-md-10">
      <h1 class="media-heading"><a href="/sign/">Sign</a></h1>
      <p>Help teach you American Sign Language (ASL).</p>
    </div>
    <img src="./assets/img/Mr_P.png" alt="MR. F. R. Print says..." class="img-responsive hidden-xs col-sm-6 col-md-2 ">
  </div>
  <ul class="nav nav-pills nav-justified lead">
    <li role="presentation"><a href="/sign/?PG=alpha">Alphabet</a></li>
    <li role="presentation" ><a href="/sign/?PG=number">Numbers</a></li>
    <li role="presentation" ><a href="/sign/?PG=quiz">Quiz</a></li>
  </ul>
</div>
<?php
if(!$_GET['PG']){
include "/home/ajwpor5/public_html/sign/_include.php";
} else {
include "//home/ajwpor5/public_html/sign/_".$_GET['PG'].".php";
}
?>

<hr>

<footer>
<p>&copy; <script>document.write(new Date().getFullYear())</script> AJWPort</p>
</footer>

</div><!--/.container-->



    <!-- Bootstrap core JavaScript
	http://getbootstrap.com/examples/offcanvas/
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--  <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
   <script src="../../dist/js/bootstrap.min.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="offcanvas.js"></script> -->
	<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.6/handlebars.min.js"></script>


  </body>
</html>
