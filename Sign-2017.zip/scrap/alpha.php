<?php
$alpha = array('a', 'b', 'c', 'd', 'e',
			   'f', 'g', 'h', 'i', 'j',
			   'k', 'l', 'm', 'n', 'o',
			   'p', 'q', 'r', 's', 't',
			   'u', 'v', 'w', 'x', 'y',
			   'z');
$arrlength = count($alpha);			   
?> 
<!DOCTYPE html>
<html>
<head>
<title>Alphabet</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

<link rel="stylesheet" href="./assets/css/style.css"/>




</head>
<body>


    <div class="container">

   
       
          <div class="jumbotron">
            <h1>Sign</h1>
            <p>Help teach you American Sign Language (ASL).</p>
          </div>
		 <h2>Alphabet</h2>
          <div class="row">
            <div class="col-xs-6 ">
        
              <ul id="js-navDetail" class="detail-nav">
				<? 
				for($x = 0; $x < $arrlength; $x++) {
					echo  "<li><a href='#detail'>" .  $alpha[$x] . "</a></li>";
				}
				?>
			  </ul>
            </div><!--/.col-xs-6-->
            <div   id="detail" class="col-xs-6 ">
              <big id="js-detail" class="ASL">z</big>
            </div><!--/.col-xs-6-->
            

          </div><!--/row-->
       
      

      <hr>

      <footer>
        <p>&copy; <script>document.write(new Date().getFullYear())</script> AJWPort</p>
      </footer>

    </div><!--/.container-->

	

    <!-- Bootstrap core JavaScript
	http://getbootstrap.com/examples/offcanvas/
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--  <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
   <script src="../../dist/js/bootstrap.min.js"></script>-->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="offcanvas.js"></script> -->
	<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.6/handlebars.min.js"></script>
	<script type="text/javascript" src="./assets/js/main.js"></script>

  </body>
</html>
