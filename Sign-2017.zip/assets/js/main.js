/* *********************
ABC & 123
********************** */
var showSign = document.querySelector('#js-detail')

var signLink = document.querySelector('#js-navDetail')
var lastActive

signLink.addEventListener('click', function(event) {
    var target
    if (event.target.tagName === "A") {
        target = event.target
    } else if (event.target.tagName === "LI") {
        target = event.target.querySelector('a')
    }

    //console.log( target.innerText ) // should (in theory) always be an <a>
    //target.className += "active"
    addClass("active", target, lastActive)

    //console.log(showSign);
    showSign.innerText = target.innerText;

    lastActive = target
    //console.log(lastActive);
})



function addClass(name, element, oldElement) {
    var classesString;
    // console.log(oldElement)
    // console.log(element);
    if (oldElement != undefined) {
        //oldElement.className -= name; //.replace(new RegExp('(?:^|\\s)'+ name + '(?:\\s|$)'), ' ');
        oldElement.className = " "
        console.log('remove ', oldElement);
    }

    classesString = element.className || ""; //?_?
    if (classesString.indexOf(name) === -1) {
        element.className += " " + name;
        console.log('add ', element);
    }


    console.log('---------------');
}
