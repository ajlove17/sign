/* *********************
Quiz
**********************
var asl = [{
  signID: Number
signName:String
signVideoPath: String
SignVideoAlt: String
signVideoIMG: String
realWorldIMG: String
}, {}
]
*/

//console.log(asl[1].signName);

// function loadQuestion() {
//   var xhttp = new XMLHttpRequest();
//   xhttp.onreadystatechange = function() {
//     if (this.readyState == 4 && this.status == 200) {
//      document.getElementById("demo").innerHTML = this.responseText;
//     }
//   };
//   xhttp.open("GET", "ajax_info.txt", true);
//   xhttp.send();
// }


function shuffleQuiz() {
    var evenOrder = [];
    var oddOrder = [];
    for (var s = 0; s < asl.length; s++) {
        if (s % 2) {
            evenOrder.push(asl[s].signID)
        } else {
            oddOrder.push(asl[s].signID)
            if (s % 3) {
                oddOrder.push(asl[s].signID)
            }
        }
        //console.log(asl[s].signID);
    }
    var newOrder = evenOrder.concat(oddOrder);

    // var newOrder =[]
    // for (var s = 0; s < asl.length; s++) {
    //   var ranNum = Math.floor((Math.random() * asl.length) + 1);
    //   newOrder.push(asl[ranNum].signID)
    //
    // }
    return newOrder;
}
// var quizOrder = shuffleQuiz();
// console.log(quizOrder);

function buildQuestion() {
    var quizOrder = shuffleQuiz();


    //get a question
    var out = '<div class="text-center">';
    out += '<a href="' + asl[quizOrder[0]].signVideoPath + '">Click to Play: <img src="' + asl[quizOrder[0]].signVideoIMG + '"></a> <p>' + asl[quizOrder[0]].SignVideoAlt + '</p>';
    out += '</div>'
    out += '<div id="js-answer" class="clearfix">'


    for (var q = 0; q < 3; q++) {
        out += '<button class="col-xs-6 col-lg-4" type="button">'
        out += '   <img src="' + asl[quizOrder[q]].realWorldIMG + '" alt="' + asl[quizOrder[q]].signName + '" class="img-responsive"/>' + asl[quizOrder[q]].signName
        out += '</button>'


    }
    // console.log(out);
    return out + "</div>"
}



quizQuestion = document.querySelector('#js-question')
quizQuestion.addEventListener('click', function(event) {
    var questionHTML = buildQuestion();
    var target
    if (event.target.tagName === "BUTTON") {
        target = event.target
    }

    quizQuestion.innerHTML = questionHTML;

    quizAnswer()

})

function quizAnswer() {

    var quizAnswer = document.querySelector('#js-answer')
    var lastActive


    quizAnswer.addEventListener('click', function(event) {
        var target
        var userAnswer

        if (event.target.tagName === "BUTTON") {
            target = event.target
            userAnswer = target.innerText
            addClass("active", target, lastActive)

        } else if (event.target.tagName === "IMG") {
            target = event.target
            userAnswer = target.getAttribute("alt")
            addClass("active", target, lastActive)
        }
        console.log(target.className) // should (in theory) always be an <button>

    })

    function addClass(name, element, oldElement) {
        var classesString;
        // console.log(oldElement)
        // console.log(element);
        if (oldElement != undefined) {
            //oldElement.className -= name; //.replace(new RegExp('(?:^|\\s)'+ name + '(?:\\s|$)'), ' ');
            oldElement.className = " "
            console.log('remove ', oldElement);
        }

        classesString = element.className || ""; //?_?
        if (classesString.indexOf(name) === -1) {
            element.className += " " + name;
            console.log('add ', element);
        }


        console.log('---------------');
    }
}
