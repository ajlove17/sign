
<h2>Quiz</h2>

<div id="js-question">
<button type="button" class="btn btn-default  btn-lg" >Take a Quiz</button>

</div>



<script type="text/javascript" src="signDB.json"></script>
<script type="text/javascript" src="./assets/js/quiz.js"></script>
