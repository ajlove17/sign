<?php
$alpha = array('a', 'b', 'c', 'd', 'e',
			   'f', 'g', 'h', 'i', 'j',
			   'k', 'l', 'm', 'n', 'o',
			   'p', 'q', 'r', 's', 't',
			   'u', 'v', 'w', 'x', 'y',
			   'z');
$arrlength = count($alpha);			   
?> 

		 <h2>Alphabet</h2>
          <div class="row">
            <div class="col-xs-5 ">
        
              <ul id="js-navDetail" class="detail-nav">
				<? 
				for($x = 0; $x < $arrlength; $x++) {
					echo  "<li><a href='#detail'>" .  $alpha[$x] . "</a></li>";
				}
				?>
			  </ul>
            </div><!--/.col-xs-6-->
            <div   id="detail" class="col-xs-7 ">
              <big id="js-detail" class="ASL">z</big>
            </div><!--/.col-xs-6-->
            

          </div><!--/row-->
       
      

    
	<script type="text/javascript" src="./assets/js/main.js"></script>

